<?php
if(isset($_GET["wrong"])){
        echo $_GET["wrong"];
    }
?>

<form action="index.html">
    <input type="submit" name="logout" value="go to mainframe!">
</form>