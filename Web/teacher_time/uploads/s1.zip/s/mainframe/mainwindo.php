<?php 
    session_start();
    if(isset($_SESSION['id'])){
    	/*include_once "frames/feach.php";
    	echo session_abort();
    	$obj = new feach_data();
    	$obj->getinfo("Select name sem branch from ".$obj->tablename.";");*/
    	echo "Hi ".$_SESSION['id']."  ->  ".$_SESSION["I_remember"];
    }else{
    	header("Location: ../");
    }
?>
<script type="text/javascript">
    function clicked() {
     
        sessionStorage.removeItem("id");
        sessionStorage.removeItem("I_remember");
        window.location.href = "../?wrong=112";

    }

</script>
    
<input type="button" name="logout" onclick="clicked()" value="logout">