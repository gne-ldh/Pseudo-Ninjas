<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="css/bootstrap.css" />
</head>
<body class="bg-dark">
<div class="container-fluid">
                        <div class="row">
                                <div id="header">   
                                    <div class="title1">     
                                        <div class="col-md-12 float-right mx-auto  p-0 mt-0 bg-warning" >
                                        <img class="  float-left mt-0 ml-4" src="logo.png" alt=""/>  
                        <button class="navbar-toggler bg-danger" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                            <span class="navbar-toggler-icon">Teacher Signin</span>
                        </button>
                        <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                                <a href="" class="nav-link">Home</a>
                            </li>
                        <li class="nav-item Teacher">
                                <a href="" class="nav-link ">Teacher</a>
                            </li>
                        </ul>
                    </div>
                    </nav>
                    <!-- NAV END -->            
                                <h4 class="mr-5 float-right font-weight-bold"><br>Atal Bihari Vajpayee Govt Institute of 
                                                    Engineering & Technology</h4><br><br><br>
                                        
                                <h6 class="mr-5 p-1 float-right">Pragatinagar, Shimla (H.P) - 171202</h6> 
                            
                        </div>
                </div>
                                </div>
                        </div><br><br><br>
                        <div class="row">
    <div class="col-md-6 p-4 bg-light mx-auto mt-0">
<table class="table table-bordered table-hover">
<thead class="thead-light">
    <tr>
    <th scope="col">subject Name</th>
    <th scope="col">Teacher name</th>
    <th scope="col">notes</th>
    <th scope="col">credits</th>
    </tr>
</thead>
<tbody>    <tr>
        <td>ADA</td>
        <td>Er. Rahul Pal</td>
        <td><a href="#">click here</a></td>
        </tr>
        <tr>
        <td>Artificial Intelligence</td>
        <td>Er. Nivedita Kashyap</td>
        <td><a href="#">click here</a></td>
        <tr>
        <td>Computer Graphics</td>
        <td>Er. Anurag Sharma</td>
        <td><a href="#">click here</a></td>
        <tr>
        <td>Computer Graphics</td>
        <td>Er. Anurag Sharma</td>
        <td><a href="#">click here</a></td><tr>
        </tbody>
</table> 
</div>
</div><br><br><br>
<hr width="85%" class="border border-danger" /> 
            <div class="row"><br/><br/>
        <div class="footer col-md-12 font-weight-bold  text-right bg-light text-secondary">
            <br><br/><br/>Designed and Developed by Moksh,Nishant,Riya,Sakshi
                 <br><br>
        </div>
                </div>
                </div>                                      
</body>

</html>