<?php
	$subject = array("ADA","DS","C++");
	for($i=0;$i<count($subject);$i++){
		echo "<div id=\"i\">".$subject[$i]."</div>";
	}