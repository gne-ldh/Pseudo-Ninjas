<?php 
    $servername = "localhost";
    $dbname = "ninjaart";
    $dbuser = "root";
    $tablename = "ninjaart";
    $dbpassword = "";

    $conn = mysqli_connect($servername,$dbuser,$dbpassword,$dbname);
