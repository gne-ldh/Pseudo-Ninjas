<!DOCTYPE HTML>
<html>
<header><header>
<body>
    <form action="upload_file.php" method="POST"  enctype="multipart/form-data">
        <input type = "file" name = "fileToUpload"><br/>
        <input type="submit" name="submit" value="submit">
    </form>
</body>
</html>